<span class="right">
<?php if($editMode){?>
	<a href="/cnous-web/index.php/adminAction/viewMode" >déconnexion</a>
<?php }?>
<a href="/cnous-web/index.php/welcome"><img src="/cnous-web/images/icon/shopping_cart.png" width="48px"/></a>
<a href="/cnous-web/index.php/welcome"><img src="/cnous-web/images/icon/yellow-home-icon.png"/></a>
</span>

