<?php if(isset($successMessage)){?>
<div class="success"><?php echo $successMessage; ?></div>
<?php }?>