<?php $this->lang->load('contact', $this->session->userdata('lg'));?>
