<a href="/cnous-web/index.php/action/info" ><button class="btn btn-normal btn-normala icon-arrow-right"><span class="menuTxt">Qui sommes-nous ?</span></button></a>
<a href="/cnous-web/index.php/action/realisation" ><button class="btn btn-normal btn-normala icon-arrow-right"><span class="menuTxt">Nos réalisations « Maison »</span></button></a>
<a href="/cnous-web/index.php/action/cadeau" ><button class="btn btn-normal btn-normala icon-arrow-right"><span class="menuTxt">Un cadeau ?</span></button></a>
<a href="/cnous-web/index.php/action/travail" ><button class="btn btn-normal btn-normala icon-arrow-right"><span class="menuTxt">Comment travaillons-nous ?</span></button></a>
<a href="/cnous-web/index.php/action/garanties" ><button class="btn btn-normal btn-normala icon-arrow-right"><span class="menuTxt">Garanties</span></button></a>
<a href="/cnous-web/index.php/action/situation" ><button class="btn btn-normal btn-normala icon-arrow-right"><span class="menuTxt">Où nous trouver ?</span></button></a>
