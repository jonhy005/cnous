<div style="text-align: center;">
	<img src="/cnous-web/images/icon/logo_midi.png" />
	<h1>Bienvenue Chez Nous</h1>
</div>
