Icon Set:	Eco Ico -- http://dribbble.com/shots/665585-Eco-Ico
License:	CC0 -- http://creativecommons.org/publicdomain/zero/1.0/